//
//  MDPContentPlayerModel.m
//  MDPClient
//
//  Created automatically with Mogenerator Templates.
//  Copyright (c) 2014 Microsoft. All rights reserved.
//

#import "_MDPContentPlayerModel.h"


#pragma mark - Interface
@interface MDPContentPlayerModel : _MDPContentPlayerModel

+ (instancetype)insertWithDictionary:(NSDictionary *)dictionary managedObjectContext:(NSManagedObjectContext *)context;

@end
