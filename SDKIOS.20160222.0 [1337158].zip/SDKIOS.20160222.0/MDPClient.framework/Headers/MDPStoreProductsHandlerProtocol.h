//
//  MDPStoreProductsHandlerProtocol.h
//  MDPClient
//
//  Created by Luis Paez Gonzalez on 4/12/15.
//  Copyright © 2015 Microsoft. All rights reserved.
//

#ifndef MDPStoreProductsHandlerProtocol_h
#define MDPStoreProductsHandlerProtocol_h

#import "MDPStoreProductModel.h"
#import "MDPProductItemModel.h"
#import "MDPPagedStoreProductsModel.h"


#pragma mark - MDPStoreProductsHandlerProtocol
@protocol MDPStoreProductsHandlerProtocol <NSObject>

/*
 Gets a store product.
 */
+ (void)getStoreProductWithIdClient:(NSString *)idClient
                          idProduct:(NSString *)idProduct
                           language:(NSString *)language
                    completionBlock:(void(^)(MDPStoreProductModel *content, NSError *error))completionBlock;


/*
 Gets a paged collection of store products.
 */
+ (void)getStoreProductsByClientIdWithIdClient:(NSString *)idClient
                                      language:(NSString *)language
                                            ct:(NSString *)ct
                               completionBlock:(void(^)(MDPPagedStoreProductsModel *content, NSError *error))completionBlock;

@end


#endif /* MDPStoreProductsHandlerProtocol_h */
