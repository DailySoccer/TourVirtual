//
//  MDPPagedAnswersModel.m
//  MDPClient
//
//  Created automatically with Mogenerator Templates.
//  Copyright (c) 2014 Microsoft. All rights reserved.
//

#import "_MDPPagedAnswersModel.h"


#pragma mark - Interface
@interface MDPPagedAnswersModel : _MDPPagedAnswersModel

+ (instancetype)insertWithDictionary:(NSDictionary *)dictionary managedObjectContext:(NSManagedObjectContext *)context;

@end






































































