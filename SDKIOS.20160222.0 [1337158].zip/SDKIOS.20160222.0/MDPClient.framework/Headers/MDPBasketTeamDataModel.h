//
//  MDPBasketTeamDataModel.m
//  MDPClient
//
//  Created automatically with Mogenerator Templates.
//  Copyright (c) 2014 Microsoft. All rights reserved.
//

#import "_MDPBasketTeamDataModel.h"


#pragma mark - Interface
@interface MDPBasketTeamDataModel : _MDPBasketTeamDataModel

+ (instancetype)insertWithDictionary:(NSDictionary *)dictionary managedObjectContext:(NSManagedObjectContext *)context;

@end
