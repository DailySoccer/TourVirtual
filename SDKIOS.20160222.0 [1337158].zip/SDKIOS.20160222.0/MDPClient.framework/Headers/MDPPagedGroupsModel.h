//
//  MDPPagedGroupsModel.m
//  MDPClient
//
//  Created automatically with Mogenerator Templates.
//  Copyright (c) 2014 Microsoft. All rights reserved.
//

#import "_MDPPagedGroupsModel.h"

@interface MDPPagedGroupsModel : _MDPPagedGroupsModel

+ (instancetype)insertWithDictionary:(NSDictionary *)dictionary fanMe:(BOOL)fanMe managedObjectContext:(NSManagedObjectContext *)context;

@end
