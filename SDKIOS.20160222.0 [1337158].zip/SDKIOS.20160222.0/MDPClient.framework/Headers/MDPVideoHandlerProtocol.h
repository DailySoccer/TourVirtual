//
//  MDPVideoHandlerProtocol.h
//  MDPClient
//
//  Created by Luis Paez Gonzalez on 30/3/15.
//  Copyright (c) 2015 Microsoft. All rights reserved.
//

#ifndef MDPClient_MDPVideoHandlerProtocol_h
#define MDPClient_MDPVideoHandlerProtocol_h

#import "MDPVideoModel.h"


#pragma mark  - Response
typedef void (^MDPVideoHandlerResponseBlock)(NSArray *response, NSError *error);


#pragma mark - MDPVideoHandlerProtocol
@protocol MDPVideoHandlerProtocol <NSObject>

/*
 */
+ (void)getVideosWithCompletionBlock:(MDPVideoHandlerResponseBlock)completionBlock;

/*
 */
+ (void)getVideosByIdWithIdVideo:(NSString *)idVideo
                 completionBlock:(void(^)(MDPVideoModel *content, NSError *error))completionBlock;

/*
 */
+ (void)getVideosBySeasonCompetitionAndMatchWithIdSeason:(NSString *)idSeason
                                           idCompetition:(NSString *)idCompetition
                                                 idMatch:(NSString *)idMatch
                                         completionBlock:(MDPVideoHandlerResponseBlock)completionBlock;

@end

#endif
