//
//  MDPPagedPlatformNotificationsModel.m
//  MDPClient
//
//  Created automatically with Mogenerator Templates.
//  Copyright (c) 2014 Microsoft. All rights reserved.
//

#import "_MDPPagedPlatformNotificationsModel.h"


#pragma mark - Interface
@interface MDPPagedPlatformNotificationsModel : _MDPPagedPlatformNotificationsModel

+ (instancetype)insertWithDictionary:(NSDictionary *)dictionary managedObjectContext:(NSManagedObjectContext *)context;

@end
