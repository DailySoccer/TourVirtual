//
//  MDPSubscriptionInformationModel.m
//  MDPClient
//
//  Created automatically with Mogenerator Templates.
//  Copyright (c) 2014 Microsoft. All rights reserved.
//

#import "_MDPSubscriptionInformationModel.h"


#pragma mark - Interface
@interface MDPSubscriptionInformationModel : _MDPSubscriptionInformationModel

+ (NSArray *)subscriptionInformationWithFanMe:(BOOL)fanMe managedObjectContext:(NSManagedObjectContext *)context;
+ (instancetype)subscriptionInformationWithIdSubscription:(NSString *)idSubscription managedObjectContext:(NSManagedObjectContext *)context;
+ (instancetype)insertIfNotExistsSubscriptionInformationWithDictionary:(NSDictionary *)dictionary fanMe:(BOOL)fanMe managedObjectContext:(NSManagedObjectContext *)context;

- (NSArray *)videoTypeArray;

@end
