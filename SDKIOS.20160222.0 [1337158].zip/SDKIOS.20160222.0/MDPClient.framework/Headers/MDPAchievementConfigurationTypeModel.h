//
//  MDPAchievementConfigurationTypeModel.m
//  MDPClient
//
//  Created automatically with Mogenerator Templates.
//  Copyright (c) 2014 Microsoft. All rights reserved.
//

#import "_MDPAchievementConfigurationTypeModel.h"


#pragma mark - Interface
@interface MDPAchievementConfigurationTypeModel : _MDPAchievementConfigurationTypeModel

+ (MDPAchievementConfigurationTypeModel *)achievementConfigurationTypeWithType:(NSString *)type managedObjectContext:(NSManagedObjectContext *)context;

+ (instancetype)insertIfNotExistsAchievementTypesWithDictionary:(NSDictionary *)dictionary managedObjectContext:(NSManagedObjectContext *)context;

+ (NSMutableDictionary *)achievementConfigurationTypeDictionayWithLanguage:(NSString *)language managedObjectContext:(NSManagedObjectContext *)context;

@end
