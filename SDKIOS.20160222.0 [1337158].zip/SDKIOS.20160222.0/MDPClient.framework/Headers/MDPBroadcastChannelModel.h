//
//  MDPBroadcastChannelModel.m
//  MDPClient
//
//  Created automatically with Mogenerator Templates.
//  Copyright (c) 2014 Microsoft. All rights reserved.
//

#import "_MDPBroadcastChannelModel.h"


#pragma mark - Interface
@interface MDPBroadcastChannelModel : _MDPBroadcastChannelModel

+ (instancetype)insertWithDictionary:(NSDictionary *)dictionary managedObjectContext:(NSManagedObjectContext *)context;

@end
