//
//  MDPScoreRankingHandlerProtocol.h
//  MDPClient
//
//  Created by Luis Paez Gonzalez on 17/12/15.
//  Copyright © 2015 Microsoft. All rights reserved.
//

#ifndef MDPScoreRankingHandlerProtocol_h
#define MDPScoreRankingHandlerProtocol_h


#pragma mark - Response
typedef void (^MDPScoreRankingHandlerResponseBlock)(NSArray *response, NSError *error);


#pragma mark - MDPScoreRankingHandlerProtocol
@protocol MDPScoreRankingHandlerProtocol <NSObject>

+ (void)postScoreWithIdGame:(NSString *)idGame
                            idScore:(NSInteger)score
                    completionBlock:(void(^)(NSError *error))completionBlock;

+ (void)getTopScoresWithIdGame:(NSString *)idGame
               completionBlock:(MDPScoreRankingHandlerResponseBlock)completionBlock;

@end


#endif /* MDPScoreRankingHandlerProtocol_h */
