//
//  MDPPagedGroupMembersModel.m
//  MDPClient
//
//  Created automatically with Mogenerator Templates.
//  Copyright (c) 2014 Microsoft. All rights reserved.
//

#import "_MDPPagedGroupMembersModel.h"


#pragma mark - Interface
@interface MDPPagedGroupMembersModel : _MDPPagedGroupMembersModel

+ (instancetype)insertWithDictionary:(NSDictionary *)dictionary managedObjectContext:(NSManagedObjectContext *)context;

@end
