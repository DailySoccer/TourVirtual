//
//  MDPRankingHandlerProtocol.h
//  MDPClient
//
//  Created by Luis Paez Gonzalez on 17/12/15.
//  Copyright © 2015 Microsoft. All rights reserved.
//

#ifndef MDPRankingHandlerProtocol_h
#define MDPRankingHandlerProtocol_h


#import "MDPExperienceRankingModel.h"


#pragma mark - Response
typedef void (^MDPRankingHandlerResponseBlock)(NSArray *response, NSError *error);


#pragma mark - MDPRankingHandlerProtocol
@protocol MDPRankingHandlerProtocol <NSObject>

+ (void)getCurrentUserRankingWithIdClient:(NSString *)idClient
                          completionBlock:(MDPRankingHandlerResponseBlock)completionBlock;

+ (void)getUserRankingWithIdClient:(NSString *)idClient
                            idUser:(NSString *)idUser
                   completionBlock:(void(^)(MDPExperienceRankingModel *content, NSError *error))completionBlock;

@end

#endif /* MDPRankingHandlerProtocol_h */
