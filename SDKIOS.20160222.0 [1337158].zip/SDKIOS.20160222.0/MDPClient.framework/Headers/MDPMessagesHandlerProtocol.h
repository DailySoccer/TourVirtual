//
//  MDPMessagesHandlerProtocol.h
//  MDPClient
//
//  Created by Luis Paez Gonzalez on 18/11/15.
//  Copyright © 2015 Microsoft. All rights reserved.
//

#ifndef MDPMessagesHandlerProtocol_h
#define MDPMessagesHandlerProtocol_h

#import "MDPPagedMessagesModel.h"
#import "MDPMessageModel.h"


#pragma mark - Response
typedef void (^MDPMessagesHandlerResponseBlock)(NSArray *response, NSError *error);


#pragma mark - MDPMessagesHandlerProtocol
@protocol MDPMessagesHandlerProtocol <NSObject>


/*
 Sends a message to a friend.
 */
+ (void)postMessageWithIdClient:(NSString *)idClient
                       idThread:(NSString *)idThread
                     idReceiver:(NSString *)idReceiver
                           text:(NSString *)text
                completionBlock:(void(^)(NSError *error))completionBlock;

/*
 Reads a message from a thread.
 */
+ (void)getMessageWithIdThread:(NSString *)idThread
                     idMessage:(NSString *)idMessage
                      idClient:(NSString *)idClient
               completionBlock:(void(^)(MDPMessageModel *content, NSError *error))completionBlock;


/*
 Read the following messages from a user.
 */
+ (void)getMessagesFromUserWithIdThread:(NSString *)idThread
                               idClient:(NSString *)idClient
                                     ct:(NSString *)ct
                        completionBlock:(void(^)(MDPPagedMessagesModel *content, NSError *error))completionBlock;

@end

#endif
