//
//  MDPTweetMediaModel.m
//  MDPClient
//
//  Created automatically with Mogenerator Templates.
//  Copyright (c) 2014 Microsoft. All rights reserved.
//

#import "_MDPTweetMediaModel.h"


#pragma mark - Interface
@interface MDPTweetMediaModel : _MDPTweetMediaModel

+ (instancetype)insertWithDictionary:(NSDictionary *)dictionary managedObjectContext:(NSManagedObjectContext *)context;

@end
