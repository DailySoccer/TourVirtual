//
//  MDPTweetUrlModel.m
//  MDPClient
//
//  Created automatically with Mogenerator Templates.
//  Copyright (c) 2014 Microsoft. All rights reserved.
//

#import "_MDPTweetUrlModel.h"


#pragma mark - Interface
@interface MDPTweetUrlModel : _MDPTweetUrlModel

+ (instancetype)insertWithDictionary:(NSDictionary *)dictionary managedObjectContext:(NSManagedObjectContext *)context;

@end
