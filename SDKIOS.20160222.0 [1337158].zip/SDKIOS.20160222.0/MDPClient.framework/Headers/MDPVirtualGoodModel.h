//
//  MDPVirtualGoodModel.m
//  MDPClient
//
//  Created automatically with Mogenerator Templates.
//  Copyright (c) 2014 Microsoft. All rights reserved.
//

#import "_MDPVirtualGoodModel.h"


#pragma mark - Interface
@interface MDPVirtualGoodModel : _MDPVirtualGoodModel

+ (instancetype)insertIfNotExistsVirtualGoodWithDictionary:(NSDictionary *)dictionary purchasable:(BOOL)purchasable managedObjectContext:(NSManagedObjectContext *)context;

+ (NSFetchedResultsController *)virtualGoodFetchedResultsControllerWithIdType:(NSString *)idType managedObjectContext:(NSManagedObjectContext *)context delegate:(id <NSFetchedResultsControllerDelegate>)delegate;

+ (NSFetchedResultsController *)virtualGoodFetchedResultsControllerWithIdType:(NSString *)idType purchasable:(BOOL)purchasable managedObjectContext:(NSManagedObjectContext *)context delegate:(id <NSFetchedResultsControllerDelegate>)delegate;

+ (NSFetchedResultsController *)virtualGoodFetchedResultsControllerWithArrayIdType:(NSArray *)arrayIdType managedObjectContext:(NSManagedObjectContext *)context delegate:(id <NSFetchedResultsControllerDelegate>)delegate;

+ (NSFetchedResultsController *)virtualGoodFetchedResultsControllerWithIdType:(NSString *)idType isHighLight:(BOOL)isHighLight isHighLighInCategory:(BOOL)isHighLightInCategory managedObjectContext:(NSManagedObjectContext *)context delegate:(id <NSFetchedResultsControllerDelegate>)delegate;

+ (NSFetchedResultsController *)virtualGoodFetchedResultsControllerWithId:(NSString *)idVirtualGood managedObjectContext:(NSManagedObjectContext *)context delegate:(id <NSFetchedResultsControllerDelegate>)delegate;

+ (NSFetchedResultsController *)virtualGoodFetchedResultsControllerWithIdType:(NSString *)idType idSubType:(NSString *)idSbubType managedObjectContext:(NSManagedObjectContext *)context delegate:(id <NSFetchedResultsControllerDelegate>)delegate;

+ (NSFetchedResultsController *)virtualGoodFetchedResultsControllerWithPurchasable:(BOOL)purchasable managedObjectContext:(NSManagedObjectContext *)context delegate:(id <NSFetchedResultsControllerDelegate>)delegate;

+ (NSFetchedResultsController *)virtualGoodFetchedResultsControllerWithIdType:(NSString *)idType isHighLight:(BOOL)isHighLight isHighLighInCategory:(BOOL)isHighLightInCategory purchasable:(BOOL)purchasable managedObjectContext:(NSManagedObjectContext *)context delegate:(id <NSFetchedResultsControllerDelegate>)delegate;

@end
