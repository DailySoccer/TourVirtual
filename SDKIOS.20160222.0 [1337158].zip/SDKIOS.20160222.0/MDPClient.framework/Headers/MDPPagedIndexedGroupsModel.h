//
//  MDPPagedIndexedGroupsModel.m
//  MDPClient
//
//  Created automatically with Mogenerator Templates.
//  Copyright (c) 2014 Microsoft. All rights reserved.
//

#import "_MDPPagedIndexedGroupsModel.h"


#pragma mark - Interface
@interface MDPPagedIndexedGroupsModel : _MDPPagedIndexedGroupsModel

+ (instancetype)insertWithDictionary:(NSDictionary *)dictionary managedObjectContext:(NSManagedObjectContext *)context;

@end
