//
//  MDPSubscriptionConfigurationTypeModel.m
//  MDPClient
//
//  Created automatically with Mogenerator Templates.
//  Copyright (c) 2014 Microsoft. All rights reserved.
//

#import "_MDPSubscriptionConfigurationTypeModel.h"


#pragma mark - Interface
@interface MDPSubscriptionConfigurationTypeModel : _MDPSubscriptionConfigurationTypeModel

+ (MDPSubscriptionConfigurationTypeModel *)subscriptionConfigurationTypeWithType:(NSString *)type
                                                            managedObjectContext:(NSManagedObjectContext *)context;

+ (instancetype)insertIfNotExistsSubscriptionTypeWithDictionary:(NSDictionary *)dictionary
                                           managedObjectContext:(NSManagedObjectContext *)context;

+ (NSFetchedResultsController *)subscriptionConfigurationTypeFetchedResultsControllerWithManagedObjectContext:(NSManagedObjectContext *)context
                                                                                                     delegate:(id <NSFetchedResultsControllerDelegate>)delegate;

+ (NSFetchedResultsController *)subscriptionConfigurationTypeFetchedResultsControllerWithHighLight:(BOOL)highLight
                                                                              managedObjectContext:(NSManagedObjectContext *)context
                                                                                          delegate:(id <NSFetchedResultsControllerDelegate>)delegate;

@end
