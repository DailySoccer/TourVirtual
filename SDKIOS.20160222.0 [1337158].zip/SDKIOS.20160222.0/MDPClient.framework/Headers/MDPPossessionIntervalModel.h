//
//  MDPPossessionIntervalModel.m
//  MDPClient
//
//  Created automatically with Mogenerator Templates.
//  Copyright (c) 2014 Microsoft. All rights reserved.
//

#import "_MDPPossessionIntervalModel.h"


#pragma mark - Interface
@interface MDPPossessionIntervalModel : _MDPPossessionIntervalModel

+ (instancetype)insertWithDictionary:(NSDictionary *)dictionary managedObjectContext:(NSManagedObjectContext *)context;

@end
