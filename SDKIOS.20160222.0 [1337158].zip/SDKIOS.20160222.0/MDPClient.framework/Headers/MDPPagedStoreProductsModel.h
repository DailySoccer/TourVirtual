//
//  MDPPagedStoreProductsModel.m
//  MDPClient
//
//  Created automatically with Mogenerator Templates.
//  Copyright (c) 2014 Microsoft. All rights reserved.
//

#import "_MDPPagedStoreProductsModel.h"


#pragma mark - Interface
@interface MDPPagedStoreProductsModel : _MDPPagedStoreProductsModel

+ (instancetype)insertWithDictionary:(NSDictionary *)dictionary managedObjectContext:(NSManagedObjectContext *)context;

@end
