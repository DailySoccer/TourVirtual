//
//  MDPPagedCommentsModel.m
//  MDPClient
//
//  Created automatically with Mogenerator Templates.
//  Copyright (c) 2014 Microsoft. All rights reserved.
//

#import "_MDPPagedCommentsModel.h"


#pragma mark - Interface
@interface MDPPagedCommentsModel : _MDPPagedCommentsModel

+ (instancetype)insertWithDictionary:(NSDictionary *)dictionary managedObjectContext:(NSManagedObjectContext *)context;

@end
