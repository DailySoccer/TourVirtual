//
//  MDPGroupModel.m
//  MDPClient
//
//  Created automatically with Mogenerator Templates.
//  Copyright (c) 2014 Microsoft. All rights reserved.
//

#import "_MDPGroupModel.h"


#pragma mark Sport Type
typedef NS_ENUM(NSInteger, MDPGroupModelGroupType) {
    MDPGroupModelGroupTypePublic             = 0,
    MDPGroupModelGroupTypePrivate            = 1,
    MDPGroupModelGroupTypeCommunity          = 2,
    MDPGroupModelGroupTypeReservedName       = 3,
} ;


#pragma mark - Interface
@interface MDPGroupModel : _MDPGroupModel

+ (MDPGroupModel *)groupWithIdGroup:(NSString *)idGroup managedObjectContext:(NSManagedObjectContext *)context;
+ (instancetype)groupWithIdSeason:(NSString *)idSeason idCompetition:(NSString *)idCompetition idMatch:(NSString *)idMatch managedObjectContext:(NSManagedObjectContext *)context;

+ (instancetype)insertIfNotExistsGroupWithFanMe:(BOOL)fanMe dictionary:(NSDictionary *)dictionary managedObjectContext:(NSManagedObjectContext *)context;

+ (instancetype)insertIfNotExistsGroupWithIdSeason:(NSString *)idSeason idCompetition:(NSString *)idCompetition idMatch:(NSString *)idMatch  dictionary:(NSDictionary *)dictionary managedObjectContext:(NSManagedObjectContext *)context;

+ (instancetype)insertWithDictionary:(NSDictionary *)dictionary managedObjectContext:(NSManagedObjectContext *)context;

@end
